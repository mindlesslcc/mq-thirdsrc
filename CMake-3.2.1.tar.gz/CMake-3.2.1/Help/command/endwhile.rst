endwhile
--------

Ends a list of commands in a while block.

::

  endwhile(expression)

See the while command.
