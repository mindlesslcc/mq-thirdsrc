Visual Studio 7
---------------

Generates Visual Studio .NET 2002 project files.
