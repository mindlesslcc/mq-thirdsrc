LINK_DIRECTORIES
----------------

List of linker search directories.

This read-only property specifies the list of directories given so far
to the link_directories command.  It is intended for debugging
purposes.
