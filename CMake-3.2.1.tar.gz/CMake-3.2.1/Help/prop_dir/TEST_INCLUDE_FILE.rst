TEST_INCLUDE_FILE
-----------------

A cmake file that will be included when ctest is run.

If you specify TEST_INCLUDE_FILE, that file will be included and
processed when ctest is run on the directory.
