.. cmake-module:: ../../Modules/FindLibXml2.cmake
